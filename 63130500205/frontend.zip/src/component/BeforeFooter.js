import React from "react";
import "../css/Beforefooter.css";

export const BeforeFooter = () => {
  return (
    <div className="container2">
      <div style={{ textAlign: "center" }}>
        <h2>Good Product For Everyone</h2>
        <p>" A good quality of life comes from getting healthy nutrients.."</p>
      </div>
    </div>
  );
};

export default BeforeFooter;
